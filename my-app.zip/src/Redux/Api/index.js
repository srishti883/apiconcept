

import axios from 'axios';
export const NEW_API_URL = "https://jsonplaceholder.typicode.com/posts"

export const HomeData = {
    fetchHomeData: () => {
        return axios.get(NEW_API_URL);
    },
}
