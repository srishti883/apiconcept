const actionTypes = {
    GET_DATA_START:"GET_DATA_START",
    GET_DATA_SUCCESS:"GET_DATA_SUCCESS",
    GET_DATA_ERROR:"GET_DATA_ERROR",


}
export default actionTypes;