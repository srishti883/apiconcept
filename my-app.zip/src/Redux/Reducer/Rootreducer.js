import { combineReducers } from "redux";
import driverPageReducer from "./driverListreducer";

export const reducer = combineReducers({
    driverPageReducer
    
})