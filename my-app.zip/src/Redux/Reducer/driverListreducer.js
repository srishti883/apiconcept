import UserActionTypes from "../Action/actionTypes";

const initialDrive = {
    addCreditCard: {
        isLoading: false,
    },
};

const initialState = {
    ...initialDrive,
    error: false,
    landingData: { landingPage: true },
};

const driverPageReducer = (state = initialState, action) => {
    switch (action.type) {
        case UserActionTypes.GET_DATA_START:
            return { ...state, error: false };
        case UserActionTypes.GET_DATA_SUCCESS:
            return {
                ...state,
                landingData: { ...action.payload, landingPage: false },
            };
        case UserActionTypes.GET_DATA_ERROR:
            return { ...state, error: true };

        default: return state
    }

    
};

export default driverPageReducer;
