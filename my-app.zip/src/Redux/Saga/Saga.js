import { put, takeLatest, all, call } from 'redux-saga/effects';
import actionTypes from '../Action/actionTypes';
import { driverListDataSuccess,driverListDataError } from '../Action/Action';
import { HomeData} from '../Api';


function* watchdriveList(){
    yield takeLatest(
        actionTypes.GET_DATA_START,
        FetchDriverListData
    )
}

function* FetchDriverListData(){
    try {
        const response = yield call(HomeData.fetchHomeData);
        const { data } = response;
        console.log("home page data data =>", data);
        yield put(driverListDataSuccess(data));
    } catch (error) {
        yield put(driverListDataError());
    }

}

export default function* rootSaga(){
    yield all([
        watchdriveList()
    ])
}