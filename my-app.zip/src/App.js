import logo from './logo.svg';
import './App.css';
import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {driverListDataStart} from './Redux/Action/Action';

function App() {

  let dispatch = useDispatch()
  const {driveData} = useSelector((state)=> state.driverPageReducer)
  console.log(driveData);
  useEffect(()=>{
      dispatch(driverListDataStart)
  },[dispatch])
   
  return (
    <div className="App">

      
      
    </div>
  );
}

export default App;
